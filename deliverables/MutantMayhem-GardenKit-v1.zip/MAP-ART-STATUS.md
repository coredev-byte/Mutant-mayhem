# Atualização visual do mapa — primeira entrega Blender/GLB

## Implementado localmente

- Dez modelos originais: cerejeira, árvore de floresta, samambaia/grama, pedras com musgo, flores, banco, lanterna, ponte, pavilhão e módulo de caminho de pedra.
- Arquivo Blender editável, materiais PBR sem texturas externas e GLBs independentes.
- Render de estudo que combina elementos das referências fornecidas; não representa uma captura do mapa no Roblox.
- `LandscapeBuilder` posiciona os modelos em jardins externos, passeio entre as praças, riacho, ponte e pavilhão. A lógica e as posições dos laboratórios e destinos permanecem nas coordenadas existentes.
- Materiais de chão e caminhos e iluminação ajustados no `MapBuilder`.
- Rojo preserva os templates importados em `ServerStorage.MM_EnvironmentAssets`.
- Instalador de Studio valida modelos e dimensões antes de substituir templates, arquivando os anteriores.

## Verificações executadas

- Dez GLBs reimportados com sucesso no Blender 4.3.2; dimensões, materiais, contagens de triângulos e geometria finita conferidos. Nenhum triângulo degenerado encontrado.
- 50 arquivos Luau passaram na compilação de sintaxe: 44 de código, cinco testes existentes e o instalador de Studio.
- Build Rojo concluído; os 44 scripts do diretório `src` foram incluídos no arquivo gerado.
- Prévia renderizada e inspecionada; enquadramento e sobreposição de pedras na ponte corrigidos.

## Pendente no Roblox

O plugin `MUTANT-MAYHEM` foi marcado pelo usuário, mas nenhuma ferramenta Roblox/MCP ficou disponível nesta sessão. Não houve importação de meshes, execução no Studio, captura em jogo, salvamento nativo ou publicação.

O código mantém os jardins anteriores enquanto os dez templates não forem importados. O build `.rbxlx` feito por Rojo contém os scripts, não os meshes GLB. Para finalizar: disponibilizar as ferramentas do MCP, importar os modelos, executar o instalador, reconstruir o mapa em Edit com backup e validar navegação, interação e desempenho no motor Roblox.

Consulte [o guia do kit](art/environment/README.md) para os comandos e passos completos. A aparência final no motor, a fidelidade às referências e o desempenho em dispositivos móveis ainda precisam de avaliação.
