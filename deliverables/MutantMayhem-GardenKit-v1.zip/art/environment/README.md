# Jardim de cerejeiras e floresta — kit Blender/GLB

Direção visual baseada nas duas referências fornecidas: cerejeiras rosadas com galhos visíveis, pedra irregular, madeira escura, lanternas, pavilhão com telhado azul e vegetação de floresta em camadas. Os dez modelos são geometria original gerada no Blender, com materiais PBR e sem dependência de texturas externas.

## Arquivos

- `MutantMayhem-GardenKit.blend`: modelos e composição de estudo editáveis.
- `glb/`: dez arquivos GLB individuais prontos para o importador 3D.
- `previews/garden-study.png`: render real do Blender da composição de estudo; não é uma captura do Roblox nem uma visualização do mapa inteiro.
- `manifest.json`: dimensões, contagem de triângulos e convenção de origem.
- `validation.json`: resultado da reimportação dos GLBs no Blender e hashes dos arquivos validados.
- `build_environment.py`: geração reproduzível, semente 6142.
- `validate_environment.py`: validação de geometria e reimportação.
- `InstallGardenTemplates.studio.luau`: instalação dos modelos importados, com validação de proporções e preservação dos templates anteriores.

## Integração com o jogo

`src/LandscapeBuilder.luau` monta os jardins a partir de `ServerStorage.MM_EnvironmentAssets`. `MapBuilder` chama esse módulo, mantendo os 12 laboratórios, o reator e as quatro praças nas posições utilizadas pelos serviços. A nova composição inclui passeio de pedra, bancos, lanternas, dois grupos de árvores, riacho ornamental, ponte e pavilhão. Folhagem e decoração não colidem; ponte e terraço usam superfícies de colisão simples separadas.

Sem os dez templates reais importados, o mapa mantém os jardins anteriores e expõe `MM_World.EnvironmentArtStatus = AwaitingGLBImport`. A geração de um `.rbxlx` com Rojo incorpora os scripts, mas **não incorpora os GLBs automaticamente**. Rojo preserva instâncias desconhecidas na pasta de templates configurada em `default.project.json`.

## Importar pelo Roblox Studio / MCP

1. Em Edit, conecte o projeto Rojo atualizado. Importe cada `glb/*.glb` pelo importador 3D, mantendo materiais, orientação e escala uniforme. A importação/publicação dos meshes deve ocorrer sob o proprietário correto da experiência.
2. Coloque os modelos importados em `Workspace.MM_EnvironmentImports`, usando exatamente os nomes dos arquivos, sem `.glb` (por exemplo, `SakuraTree`). O GLB usa Y-up; não aplique uma rotação extra de 90 graus. O instalador ajusta a conversão de unidades pelas dimensões medidas.
3. Execute `InstallGardenTemplates.studio.luau` pela ferramenta de execução do MCP ou pela Command Bar. O script valida todos os modelos antes de instalar e arquiva os templates anteriores.
4. Antes de reconstruir, clone `Workspace.MM_World` para um backup com nome exclusivo em `ServerStorage`. Então execute `require(game.ServerScriptService.MM.MapBuilder).Build()` em Edit. O construtor substitui apenas `MM_World`.
5. Confira `EnvironmentArtStatus == "GLBTemplatesInstalled"`, as cores importadas, escala das árvores, orientação dos bancos e pavilhão, travessia da ponte, ausência de obstruções e acesso aos 12 laboratórios.
6. Em Play, verifique spawn, colocar/coletar pet, reator e deslocamento às quatro praças. Inspecione erros no console e desempenho em celular; ainda não há resultado de aceitação desses checks.
7. Salve um novo `.rbxl` depois da inspeção. Publicação da experiência Roblox não foi realizada nesta alteração.

O MCP `MUTANT-MAYHEM` foi indicado na conversa, mas não expôs ferramentas à sessão de execução. A importação, a aparência no motor Roblox, colisões, desempenho e o salvamento nativo permanecem pendentes.

## Reproduzir

Na raiz `outputs/MutantMayhem`:

```bash
blender -b -t 4 --python art/environment/build_environment.py
blender -b -t 2 --python art/environment/validate_environment.py
/workspace/.mutant-tools/bin/rojo build default.project.json -o /workspace/.mutant-build/MutantMayhem-garden-source.rbxlx
```

Blender 4.3.2, render Cycles CPU, 64 amostras. O gerador atualiza os GLBs, manifesto, dimensões Luau e render. Os modelos têm de 60 a 16.624 triângulos por asset. Instâncias reutilizam a mesma malha; o custo efetivo no Roblox precisa ser medido após importação.
