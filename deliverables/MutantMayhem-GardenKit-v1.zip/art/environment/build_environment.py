"""Reproducible Blender 4.3 environment kit. Run with blender -b -t 4 --python this_file.

Original geometry, no external textures. One Blender unit = one intended Roblox stud.
The garden study is an art preview, not a Roblox gameplay capture.
"""
import bpy
import math
import random
import json
from pathlib import Path
from mathutils import Vector

ROOT = Path(__file__).resolve().parent
R = random.Random(6142)
bpy.ops.object.select_all(action='SELECT')
bpy.ops.object.delete(use_global=False)
for c in list(bpy.data.collections):
    if c.name != 'Collection':
        bpy.data.collections.remove(c)
KIT = bpy.data.collections.new('MM_EnvironmentAssets')
bpy.context.scene.collection.children.link(KIT)
MATS = {}


def material(name, color, roughness=.8, metallic=0):
    m = bpy.data.materials.new(name)
    m.diffuse_color = (*color, 1)
    m.use_nodes = True
    bs = m.node_tree.nodes.get('Principled BSDF')
    bs.inputs['Base Color'].default_value = (*color, 1)
    bs.inputs['Roughness'].default_value = roughness
    bs.inputs['Metallic'].default_value = metallic
    MATS[name] = m
    return m


for name, color in {
    'Bark': (.20,.105,.065), 'BarkLight': (.34,.20,.11),
    'SakuraRose': (.89,.25,.48), 'SakuraLight': (1,.53,.69), 'SakuraBlush': (.98,.37,.59),
    'PineDeep': (.035,.19,.11), 'PineLeaf': (.075,.34,.16), 'PineLight': (.16,.46,.21),
    'Fern': (.11,.39,.16), 'FernLight': (.26,.55,.20),
    'Stone': (.39,.47,.46), 'StoneLight': (.55,.61,.58), 'StoneDark': (.25,.32,.32),
    'Moss': (.22,.34,.115), 'Wood': (.32,.115,.065), 'WoodEdge': (.53,.235,.12),
    'Iron': (.055,.09,.105), 'Roof': (.055,.12,.17), 'RoofEdge': (.13,.24,.29),
    'Ivory': (.85,.78,.58), 'PetalWhite': (.96,.87,.86), 'FlowerGold': (.92,.62,.10),
    'Ground': (.20,.38,.13), 'Bank': (.28,.34,.21), 'Mountain': (.17,.34,.38),
}.items():
    material(name, color)
water = material('Water', (.045,.38,.42), .19, .25)
glow = material('LanternGlass', (1,.67,.26), .4)
bs = glow.node_tree.nodes.get('Principled BSDF')
bs.inputs['Emission Color'].default_value = (1,.43,.09,1)
bs.inputs['Emission Strength'].default_value = .6


def mesh(name, verts, faces, mat):
    data = bpy.data.meshes.new(name)
    data.from_pydata(verts, [], faces)
    data.materials.append(MATS[mat])
    obj = bpy.data.objects.new(name, data)
    bpy.context.collection.objects.link(obj)
    return obj


def box(name, pos, size, mat, bevel=0):
    bpy.ops.mesh.primitive_cube_add(size=1, location=pos)
    o = bpy.context.object
    o.name = name
    o.dimensions = size
    bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    o.data.materials.append(MATS[mat])
    if bevel:
        mod = o.modifiers.new('Soft hand-cut edges', 'BEVEL')
        mod.width = bevel
        mod.segments = 2
        bpy.ops.object.modifier_apply(modifier=mod.name)
        o.modifiers.new('Weighted corner normals', 'WEIGHTED_NORMAL')
        bpy.ops.object.modifier_apply(modifier=o.modifiers[-1].name)
    return o


def branch(name, a, b, r1, r2, mat='Bark', sides=8):
    a, b = Vector(a), Vector(b)
    axis = (b-a).normalized()
    u = axis.cross(Vector((0,0,1)))
    if u.length < .01:
        u = axis.cross(Vector((0,1,0)))
    u.normalize()
    v = axis.cross(u)
    verts = [tuple(center + radius*(u*math.cos(i*math.tau/sides)+v*math.sin(i*math.tau/sides)))
             for center, radius in ((a,r1),(b,r2)) for i in range(sides)]
    faces = [(i,(i+1)%sides,(i+1)%sides+sides,i+sides) for i in range(sides)]
    faces += [tuple(reversed(range(sides))),tuple(range(sides,sides*2))]
    return mesh(name, verts, faces, mat)


def leaves(name, centers, pink=False):
    # Individually modeled folded leaves/petals: opaque geometry, no alpha sorting.
    verts, faces, indices = [], [], []
    palette = ['SakuraRose','SakuraLight','SakuraBlush'] if pink else ['PineDeep','PineLeaf','PineLight']
    for center, spread, count in centers:
        for _ in range(round(count * (1.7 if pink else 1.3))):
            theta = R.uniform(0, math.tau)
            cos_phi = R.uniform(-1,1)
            radial = R.random()**.5
            xy = math.sqrt(1-cos_phi*cos_phi)
            p = Vector(center)+Vector((math.cos(theta)*xy*spread[0], math.sin(theta)*xy*spread[1],cos_phi*spread[2]))*radial
            angle = R.uniform(0,math.tau)
            length = R.uniform(.24,.53) if pink else R.uniform(.36,.78)
            u = Vector((math.cos(angle),math.sin(angle),R.uniform(-.35,.35)))*length
            v = Vector((-math.sin(angle),math.cos(angle),.15))*length*.48
            k = len(verts)
            verts.extend(tuple(p+d) for d in (-u,v,u,-v,Vector((0,0,.12))))
            faces.extend([(k,k+1,k+4),(k+1,k+2,k+4),(k+2,k+3,k+4),(k+3,k,k+4)])
            indices.extend([R.choices([0,1,2],[2,4,5])[0]]*4)
    o = mesh(name, verts, faces, palette[0])
    for m in palette[1:]:
        o.data.materials.append(MATS[m])
    for p, idx in zip(o.data.polygons, indices):
        p.material_index = idx
    return o


ASSETS = {}
MANIFEST = {}


def asset(name, build):
    before = set(bpy.data.objects)
    build()
    parts = [o for o in bpy.data.objects if o not in before and o.type=='MESH']
    # Group by material without exceeding the importer triangle budget per mesh.
    bpy.ops.object.select_all(action='DESELECT')
    for o in parts:
        o.select_set(True)
    bpy.context.view_layer.objects.active = parts[0]
    bpy.ops.object.join()
    combined = bpy.context.object
    combined.name = name
    bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)
    coords = [v.co for v in combined.data.vertices]
    lo = Vector(tuple(min(v[i] for v in coords) for i in range(3)))
    hi = Vector(tuple(max(v[i] for v in coords) for i in range(3)))
    shift = Vector(((lo.x+hi.x)/2,(lo.y+hi.y)/2,lo.z))
    for v in combined.data.vertices:
        v.co -= shift
    combined.data.calc_loop_triangles()
    triangles = len(combined.data.loop_triangles)
    assert triangles <= 20000, (name,triangles)
    for collection in list(combined.users_collection):
        collection.objects.unlink(combined)
    KIT.objects.link(combined)
    ASSETS[name] = combined
    MANIFEST[name] = {'file':f'glb/{name}.glb','triangles':triangles,
                      'sizeRoblox':[round(hi.x-lo.x,4),round(hi.z-lo.z,4),round(hi.y-lo.y,4)],
                      'pivot':'bottom-center','collision':'none; separate gameplay colliders'}
    bpy.ops.export_scene.gltf(filepath=str(ROOT/'glb'/f'{name}.glb'),export_format='GLB',
        use_selection=True,export_yup=True,export_cameras=False,export_lights=False,
        export_extras=True)
    combined.hide_render = True
    combined.hide_set(True)


def sakura():
    branch('Rooted trunk',(0,0,0),(.3,.1,6),.85,.47)
    for angle in range(0,360,60):
        a = math.radians(angle)
        branch('Surface roots',(0,0,.3),(1.6*math.cos(a),1.6*math.sin(a),.1),.4,.08)
    centers=[]
    for i in range(8):
        a = i*math.tau/8+.2
        tip = (math.cos(a)*R.uniform(3,4.9),math.sin(a)*R.uniform(3,4.9),R.uniform(7.5,10.5))
        mid=(tip[0]*.4,tip[1]*.4,6+R.uniform(-.6,.8))
        branch('Expressive branch',(.3,.1,4.4),mid,.30,.19)
        branch('Fine branch',mid,tip,.19,.06)
        centers.append((tip,(2.5,2.5,1.6),250))
    centers.append(((.3,0,11),(2.6,2.6,1.8),350))
    leaves('Layered cherry blossoms',centers,True)


def forest():
    branch('Tall cedar trunk',(0,0,0),(.2,0,17),.62,.12)
    centers=[]
    for level in range(4):
        z=7+level*3.2
        radius=4.6-level*.65
        for j in range(4):
            a=j*math.tau/4+level*.7
            tip=(math.cos(a)*radius*.65,math.sin(a)*radius*.65,z+.4)
            branch('Cedar bough',(.1,0,z-1.6),tip,.16,.035)
            centers.append((tip,(radius*.7,radius*.7,1.3),190))
    leaves('Layered cedar needles',centers)


def fern():
    # Tufted understory softens the contact with the ground; geometry survives GLB import.
    for _ in range(130):
        a=R.uniform(0,math.tau); radius=R.uniform(.2,1.8)
        p=Vector((math.cos(a)*radius,math.sin(a)*radius,0))
        lean=Vector((math.cos(a),math.sin(a),0))*R.uniform(.1,.45)
        side=Vector((-math.sin(a),math.cos(a),0))*.045
        height=R.uniform(.24,.75)
        mesh('Grass blade',[p-side,p+side,p+lean+Vector((0,0,height))],[(0,1,2)],'FernLight' if R.random()<.3 else 'Fern')
    for j in range(9):
        a=j*math.tau/9
        direction=Vector((math.cos(a),math.sin(a),0))
        last=Vector((0,0,.05))
        for i in range(1,7):
            t=i/6
            p=direction*(2.2*t)+Vector((0,0,math.sin(t*2.3)*1.4))
            branch('Frond stem',last,p,.025,.015,'Fern',5)
            for sign in (-1,1):
                side=Vector((-direction.y,direction.x,0))*sign
                tip=p+side*(.65*(1-t)+.12)+direction*.28
                mesh('Fern leaflet',[p,p+direction*.15,tip+Vector((0,0,.09)),p-direction*.12],[(0,1,2),(0,2,3)],'FernLight' if i%2 else 'Fern')
            last=p


def rock():
    for pos,size in [((0,0,.8),(2.8,2.2,1.7)),((1.9,.6,.35),(1.5,1.2,.8)),((-.9,1,.3),(1.4,1.3,.7))]:
        bpy.ops.mesh.primitive_ico_sphere_add(subdivisions=1,radius=1,location=pos)
        o=bpy.context.object; o.name='Weathered river stone'; o.scale=size
        o.data.materials.append(MATS['Stone']); o.data.materials.append(MATS['Moss']); o.data.materials.append(MATS['StoneLight'])
        for p in o.data.polygons:
            p.material_index = 1 if p.normal.z>.45 else (2 if R.random()<.25 else 0)


def flowers():
    for j in range(17):
        x,y=R.uniform(-1.6,1.6),R.uniform(-1.2,1.2)
        z=R.uniform(.6,1.5)
        branch('Flower stem',(x,y,0),(x,y,z),.035,.018,'Fern',5)
        for k in range(5):
            a=k*math.tau/5
            center=Vector((x,y,z)); u=Vector((math.cos(a),math.sin(a),.15))*.4
            v=Vector((-math.sin(a),math.cos(a),0))*.19
            mesh('Flower petal',[center,center+u*.55+v,center+u,center+u*.55-v],[(0,1,2,3)],'SakuraLight' if j%3 else 'PetalWhite')
        box('Golden center',(x,y,z+.025),(.12,.12,.09),'FlowerGold',.025)


def bench():
    for x in (-2.5,2.5):
        for y in (-.65,.65):
            box('Cast iron leg',(x,y,.8),(.18,.22,1.6),'Iron',.04)
        branch('Curved back support',(x,.65,.8),(x,1.05,3.2),.10,.1,'Iron')
        box('Armrest',(x,0,2.2),(.25,2,.18),'Iron',.06)
    for j in range(4):
        box('Oiled wooden seat',(0,-.7+j*.44,1.5),(6,.37,.16),'WoodEdge' if j%2 else 'Wood',.05)
    for j in range(3):
        o=box('Backrest slat',(0,.87+j*.07,2.05+j*.42),(6,.15,.32),'Wood',.04)
        o.rotation_euler.x=-.17


def lantern():
    box('Stone plinth',(0,0,.2),(1.8,1.8,.4),'StoneDark',.12)
    box('Carved pedestal',(0,0,1),(1,1,1.4),'Stone',.12)
    box('Lantern sill',(0,0,1.85),(1.6,1.6,.25),'StoneLight',.08)
    box('Warm glass',(0,0,2.5),(.9,.9,1.05),'LanternGlass',.02)
    for x in (-.62,.62):
        for y in (-.62,.62): box('Frame',(x,y,2.5),(.16,.16,1.2),'StoneDark',.03)
    for i in range(3):
        box('Layered lantern cap',(0,0,3.12+i*.16),(2-i*.35,2-i*.35,.22),'Roof',.07)


def bridge():
    # Walkable wooden arch, with matching segmented invisible colliders in Roblox.
    for i in range(21):
        y=-7.5+i*.75
        z=.3+1.4*(1-(y/8)**2)
        plank=box('Bridge deck plank',(0,y,z),(7,.70,.24),'WoodEdge' if i%4==0 else 'Wood',.045)
        plank.rotation_euler.x=math.atan(-2.8*y/64)
    for x in (-3.6,3.6):
        for y in (-7.5,-3.75,0,3.75,7.5):
            z=.3+1.4*(1-(y/8)**2)
            box('Rail post',(x,y,z+1.45),(.26,.26,3),'Wood',.05)
            box('Brass post cap',(x,y,z+3),(.38,.38,.13),'Ivory',.03)
        for i in range(20):
            y=-7.5+i*.75; yn=y+.75
            for height in (1.2,2.8):
                branch('Continuous arched rail',(x,y,.3+1.4*(1-(y/8)**2)+height),(x,yn,.3+1.4*(1-(yn/8)**2)+height),.105,.105,'WoodEdge',6)


def pavilion():
    box('Pavilion stone terrace',(0,0,.35),(13,11,.7),'Stone',.18)
    for j in range(3):
        box('Entry step',(0,-6.2+j*.45,.12+j*.17),(7,1.8,.24+j*.20),'StoneLight',.08)
    for x in (-4.7,4.7):
        for y in (-3.8,3.8):
            box('Column foot',(x,y,.85),(1.2,1.2,.4),'StoneDark',.08)
            box('Vermilion timber column',(x,y,4.9),(.65,.65,8),'Wood',.09)
            box('Gold column collar',(x,y,7.8),(.78,.78,.25),'Ivory',.03)
    for y in (-3.8,3.8):
        box('Lintel',(0,y,8.8),(11,.6,.7),'WoodEdge',.05)
        for x in (-3,-1.5,0,1.5,3): box('Lattice detail',(x,y,8),( .16,.18,1),'WoodEdge',.02)
    for side in (-1,1):
        for j in range(22):
            y=-6+j*.56
            for k in range(7):
                x=side*k*1.08
                z=12-abs(x)*.48+max(0,abs(x)-4.2)**2*.18
                tile=box('Indigo roof tile',(x,y,z),(1.15,.53,.18),'RoofEdge' if j%4==0 else 'Roof')
                tile.rotation_euler.y=side*.24
    branch('Roof ridge',(0,-6.4,12.25),(0,6.4,12.25),.20,.20,'RoofEdge')


def path():
    for row in range(4):
        for col in range(3):
            x=(col-1)*2.05+(row%2)*.18
            y=(row-1.5)*1.85
            stone=box('Hand-laid stone',(x+R.uniform(-.06,.06),y,.12+R.uniform(-.025,.025)),(1.92,1.72,.26),R.choice(['Stone','StoneLight','StoneDark']),.16)
            stone.rotation_euler.z=R.uniform(-.045,.045)


for name,fn in [('SakuraTree',sakura),('ForestTree',forest),('FernCluster',fern),('MossRock',rock),
                ('FlowerBed',flowers),('GardenBench',bench),('StoneLantern',lantern),
                ('GardenBridge',bridge),('Pavilion',pavilion),('StonePath',path)]:
    asset(name,fn)

# Art study: an actual Blender scene using the exported mesh kit.
STUDY=bpy.data.collections.new('Garden study — art preview, not gameplay')
bpy.context.scene.collection.children.link(STUDY)


def instance(name,x,y,z=0,scale=1,angle=0):
    o=ASSETS[name].copy(); o.data=ASSETS[name].data
    STUDY.objects.link(o); o.name=name+'_study'
    o.hide_render=False; o.hide_set(False)
    o.location=(x,y,z); o.scale=(scale,)*3; o.rotation_euler.z=angle
    return o


ground=box('Garden island',(0,9,-1),(85,96,2),'Ground',.8)
box('Jade stream',(0,5,.02),(84,7,.10),'Water',.03)
for side in (-1,1):
    for j in range(20):
        scale,angle=R.uniform(.4,.8),R.uniform(0,6)
        x=-39+j*4
        if abs(x)>=8: instance('MossRock',x,5+side*4.2,-.3,scale,angle)
instance('GardenBridge',0,5,0,1.2)
instance('Pavilion',-5,31,0,1.3)
for y in range(-27,-3,7): instance('StonePath',0,y,0,1.1)
for y in range(16,29,7): instance('StonePath',-2,y,0,1.1)
for x,y,s in [(-13,-13,1.25),(-22,2,1.4),(16,17,1.4),(-17,23,1.2),(16,-15,1.1),(-28,35,1.5),(20,34,1.3)]:
    instance('SakuraTree',x,y,0,s,R.random()*6)
for x,y in [(30,-4),(32,15),(27,28),(12,42),(-12,44),(-34,19),(-36,41),(36,40),(34,-21)]:
    instance('ForestTree',x,y,0,R.uniform(1,1.6),R.random()*6)
for x,y,a in [(-8,-16,-.25),(9,-17,.25),(-11,18,.4),(12,24,-.4)]:
    instance('GardenBench',x,y,0,1.1,a)
for x,y in [(-5,-5),(5,-5),(-5,15),(5,15),(-12,29),(4,29)]: instance('StoneLantern',x,y)
for i in range(95):
    x,y=R.uniform(-37,37),R.uniform(-32,45)
    if abs(x)<7 or abs(y-5)<5: continue
    instance('FernCluster' if i%3 else 'FlowerBed',x,y,0,R.uniform(.65,1.4),R.random()*6)
for i in range(22):
    x,y=R.uniform(-38,38),R.uniform(-30,45)
    if abs(x)>8 and abs(y-5)>5: instance('MossRock',x,y,0,R.uniform(.3,.8),R.random()*6)

# Distant low-poly mountain silhouettes, only for the art-study composition.
for i in range(9):
    x=-70+i*18
    bpy.ops.mesh.primitive_cone_add(vertices=7, radius1=R.uniform(15,24), radius2=2,
        depth=R.uniform(35,55),location=(x,75,15))
    o=bpy.context.object; o.name='Distant mountain'; o.data.materials.append(MATS['Mountain'])

scene=bpy.context.scene
scene.render.engine='CYCLES'
scene.cycles.samples=64
scene.cycles.use_denoising=False  # Debian Blender build does not include OpenImageDenoise.
scene.render.resolution_x=1440; scene.render.resolution_y=960; scene.render.resolution_percentage=100
scene.world.use_nodes=True
scene.world.node_tree.nodes['Background'].inputs[0].default_value=(.37,.66,.86,1)
scene.world.node_tree.nodes['Background'].inputs[1].default_value=.8
bpy.ops.object.light_add(type='SUN',location=(0,-20,40))
sun=bpy.context.object; sun.name='Soft afternoon sun'; sun.data.energy=3.2; sun.data.angle=.10
sun.rotation_euler=(math.radians(24),math.radians(-22),math.radians(-30))
bpy.ops.object.camera_add(location=(8,-46,18))
camera=bpy.context.object; camera.name='Garden art review'
camera.rotation_euler=(Vector((0,13,6))-camera.location).to_track_quat('-Z','Y').to_euler()
camera.data.lens=32
scene.camera=camera
scene.view_settings.view_transform='AgX'
scene.render.image_settings.file_format='PNG'
scene.render.filepath=str(ROOT/'previews'/'garden-study.png')
manifest={'version':1,'generator':'Blender 4.3.2; build_environment.py; seed 6142',
          'units':'1 Blender unit = 1 intended Roblox stud; normalize imported bounds using sizeRoblox',
          'assets':MANIFEST,'robloxImportVerified':False,
          'preview':'Blender art study, not a Roblox screenshot'}
(ROOT/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
asset_info = '-- Generated by art/environment/build_environment.py; dimensions in Roblox XYZ.\nreturn {\n'
for name, data in MANIFEST.items():
    asset_info += '\t%s = Vector3.new(%s),\n' % (name, ', '.join(map(str,data['sizeRoblox'])))
asset_info += '}\n'
(ROOT.parent.parent/'src'/'EnvironmentAssetInfo.luau').write_text(asset_info)
bpy.context.preferences.filepaths.save_version = 0
bpy.ops.wm.save_as_mainfile(filepath=str(ROOT/'MutantMayhem-GardenKit.blend'))
bpy.ops.render.render(write_still=True)
print('MM_ENVIRONMENT_COMPLETE',json.dumps({k:v['triangles'] for k,v in MANIFEST.items()}))
