"""Validate actual GLB round trips in Blender. Does not simulate Roblox import."""
import bpy
import json
import math
import hashlib
from pathlib import Path

root = Path(__file__).resolve().parent
manifest = json.loads((root / 'manifest.json').read_text())
results = []
for name, expected in manifest['assets'].items():
    bpy.ops.wm.read_factory_settings(use_empty=True)
    path = root / expected['file']
    bpy.ops.import_scene.gltf(filepath=str(path))
    meshes = [o for o in bpy.context.scene.objects if o.type == 'MESH']
    assert meshes, name
    coords = [o.matrix_world @ v.co for o in meshes for v in o.data.vertices]
    assert all(math.isfinite(x) for v in coords for x in v), name
    minimum = [min(v[i] for v in coords) for i in range(3)]
    maximum = [max(v[i] for v in coords) for i in range(3)]
    size = [maximum[i]-minimum[i] for i in (0,2,1)]
    assert all(abs(a-b) < .002 for a,b in zip(size,expected['sizeRoblox'])), (name,size)
    assert abs(minimum[2]) < .002, (name,minimum)
    total = 0
    for obj in meshes:
        obj.data.calc_loop_triangles()
        assert len(obj.data.loop_triangles) <= 20000, name
        assert obj.data.materials and all(m.use_nodes for m in obj.data.materials), name
        total += len(obj.data.loop_triangles)
        for tri in obj.data.loop_triangles:
            a,b,c = (obj.data.vertices[i].co for i in tri.vertices)
            assert (b-a).cross(c-a).length > 1e-10, (name, 'degenerate triangle')
    assert total == expected['triangles'], (name,total)
    results.append({'asset':name,'triangles':total,'boundsMatch':True,
                    'sha256':hashlib.sha256(path.read_bytes()).hexdigest()})
report={'tool':bpy.app.version_string,'check':'GLB reimport, bounds, materials, triangles, finite geometry',
        'passed':len(results),'failed':0,'assets':results,'robloxStudioValidated':False}
(root/'validation.json').write_text(json.dumps(report,indent=2)+'\n')
print('PASS:',len(results),'GLB assets reimported and validated')
